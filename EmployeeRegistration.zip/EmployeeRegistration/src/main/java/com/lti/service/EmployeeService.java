package com.lti.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.model.Employee;
import com.lti.repo.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	

	public List<String> getGender() {

		List<String> gender = new ArrayList<>();

		gender.add("male");
		gender.add("female");

		return gender;
	}
	
	
	public List<String> getLocation() {

		List<String> location = new ArrayList<>();
		location.add(" ");

		location.add("Pune");
		location.add("HYD");
		location.add("Mum");
		location.add("CSK");
		location.add("Delhi");
		location.add("Noida");

		return location;
	}

	public List<String> getTimings() {

		List<String> timings = new ArrayList<>();

		timings.add("Morning");
		timings.add("Afternoon");
		timings.add("Evening");

		return timings;
	}

}
