package com.lti.service;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hello";
		
		str=str.concat("java");
		
		System.out.println(str);

	}

}
