package com.lti.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.lti.model.Employee;
import com.lti.service.EmployeeService;
@Controller
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/emp")
	public String loadLoginForm(Model model) {
		
		Employee emp=new Employee();
		model.addAttribute("employee", emp);
		
		model.addAttribute("genders", employeeService.getGender());
		
		model.addAttribute("locations", employeeService.getLocation());
		
		model.addAttribute("timings", employeeService.getTimings());
		
		
		return "registration";
	}

	
	@PostMapping("/empReg")
	public String handleRegister(Employee employee,Model model) {
		
		System.out.println(employee);
		
		model.addAttribute("Name", employee.getFname()+"  "+ employee.getLname()+" your location is "+employee.getLocation()+" and Shift timing "+employee.getTimings());
		
		return"success";
		
	}
}
